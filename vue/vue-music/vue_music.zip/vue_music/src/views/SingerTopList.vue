<template>
    <div class="" id="SingerTopList">
        SingerTopList
    </div>
</template>

<script>
export default {
    name:'SingerTopList',
}
</script>

<style lang="stylus" scoped>
#SingerTopList{
    position absolute
    width 100%
    height 100%
    z-index 2
    background-color #fff
}
</style>
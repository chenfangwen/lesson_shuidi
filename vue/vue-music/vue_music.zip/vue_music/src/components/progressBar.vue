<template>
    <div class="progress-bar" ref="progressBar" @click.stop="progressClick">
    <div class="bar-inner">
      <div class="progress" ref="progress"></div>
      <div class="progress-btn-wrapper" ref="progressBtn"
      @touchstart.prevent="progressTouchStart"
      @touchmove.prevent="progressTouchMove"
      @touchend.prevent="progressTouchEnd">
        <div v-if="showBtn" class="progress-btn"></div>
      </div>
    </div>
  </div>
</template>

<script>
import {prefixStyle} from '../common/js/dom'
const progressBtnWidth = 16
const transform = prefixStyle('transform')
export default {
    data(){
        return {
            showBtn:false
        }
    },
    props: {
      percent: {
        type: Number,
        default: 0
      }
    },
    computed:{
    },
    watch: {
      percent (newPercent) {
        // console.log(newPercent)
        if (newPercent >= 0 && !this.touch.initiated) {
          const barWidth = this.$refs.progressBar.clientWidth - progressBtnWidth
          const offsetWidth = newPercent * barWidth
          this._offset(offsetWidth)
        }
      }
    },
    methods:{
      changeBtn(b){
        this.showBtn = b
      },
        progressTouchStart (e) {
            this.changeBtn(true)
          this.touch.initiated = true
          this.touch.startX = e.touches[0].pageX
          this.touch.left = this.$refs.progress.clientWidth
        },
        progressClick (e) {
            // 这个有 bug
            // this._offset(e.offsetX)
            this.changeBtn(true)
            const rect = this.$refs.progressBar.getBoundingClientRect()
            // rect.left 元素距离左边的距离
            // e.pageX 点击距离左边的距离
            const offsetWidth = e.pageX - rect.left
            // console.log(rect, e.pageX)
            this._offset(offsetWidth)
            const barWidth = this.$refs.progressBar.clientWidth - progressBtnWidth
            const percent = this.$refs.progress.clientWidth / barWidth
            this.$emit('percentChangeEnd', percent)
        },
        progressTouchMove (e) {
          // if (!this.touch.initiated) {
          //   return
          // }
          this.changeBtn(true)
          this._triggerPercent()
          const deltaX = e.touches[0].pageX - this.touch.startX
          const offsetWidth = Math.min(Math.min(this.$refs.progressBar.clientWidth - progressBtnWidth, Math.max(0, this.touch.left + deltaX)))
          this._offset(offsetWidth)
        },
        progressTouchEnd (e) {
          this.changeBtn(true)
          this.touch.initiated = false
          const barWidth = this.$refs.progressBar.clientWidth - progressBtnWidth
          const percent = this.$refs.progress.clientWidth / barWidth
          this.$emit('percentChangeEnd', percent)
        },
        _triggerPercent () {
          const barWidth = this.$refs.progressBar.clientWidth - progressBtnWidth
          const percent = this.$refs.progress.clientWidth / barWidth
          this.$emit('percentChange', percent)
        },
        _offset (offsetWidth) {
            const btnLeft = offsetWidth - progressBtnWidth
            this.$refs.progress.style.width = `${offsetWidth}px`
            this.$refs.progressBtn.style[transform] = `translate3d(${offsetWidth}px, 0, 0)`
        },

    },
    created(){
      this.touch = {}
      // setInterval(()=>{
      //   this.$emit('percentChange', percent)
      // })
    }
}
</script>


<style scoped lang="stylus">
.progress-bar {
  height: 30px;
  .bar-inner {
    position: relative;
    top: 13px;
    height: 4px;
    background: rgba(0, 0, 0, 0.3);
    .progress {
      position: absolute;
      height: 100%;
      background:  rgb(212, 68, 57);
    }
    .progress-btn-wrapper {
      position: absolute;
      left: -8px;
      top: -13px;
      width: 30px;
      height: 30px;
      .progress-btn {
        position: relative;
        top: 7px;
        left: 7px;
        box-sizing: border-box;
        width: 16px;
        height: 16px;
        border: 5px solid rgb(241, 241, 241);
        border-radius: 50%;
        background:  rgb(212, 68, 57);
      }
    }
  }
}
</style>